//Write a program to calculate sum of cubes of first N natural numbers.
#include <stdio.h>
int main()
{
    int num,s,i;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=1,s=0;i<=num;i++)
    {
        s=s+i*i*i;
    }
    printf("sum is: %d",s);
    return 0;
}

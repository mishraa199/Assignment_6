//Write a program to check whether a given number is a Prime number or not.
#include <stdio.h>
int main()
{
    int num,i,flag=0;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=2; i<=num/2; i++)
    {
        if(num%i==0)

        {
             flag=1;
             break;
        }
    }
    if(flag==1)
        printf("Not prime");
    else
        printf("Prime");
    return 0;
}

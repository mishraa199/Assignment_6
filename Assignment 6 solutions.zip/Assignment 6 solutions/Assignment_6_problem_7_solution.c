//Write a program to count digits in a given number.
#include <stdio.h>
int main()
{
    int num,count;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(count=0;num!=0;count++)

    {
       num=num/10;
    }
    printf("Number of digit is %d",count);
    return 0;
}

//Write a program to reverse a given number.
#include <stdio.h>
int main()
{
    int num,reminder,reverse=0;
    printf("Enter any number: ");
    scanf("%d",&num);
    while(num!=0)
    {
        reminder=num%10;
        num= num/10;
        reverse= reverse*10+reminder;
    }
    printf("Reverse number is %d",reverse);
}

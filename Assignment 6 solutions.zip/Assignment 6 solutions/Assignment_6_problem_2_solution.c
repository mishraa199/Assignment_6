//Write a program to calculate sum of first N even natural numbers.
#include <stdio.h>
int main ()
{
    int num,s,i;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=1,s=0;i<=num;i++)
    {
        s=s+i*2;
    }
    printf("sum is %d",s);
    return 0;
}
